<?php
// Server-side configuration. Keep this file outside public access if your host allows it.
// The password below is stored as a one-way hash. Change it from admin/config.php if needed.

define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD_HASH', '$2y$12$seyUn6wn4vwyxdWgLKnHeequkw4LD89QwqcefkoFJdUrAAKvxdpLW');
define('DATA_DIR', __DIR__ . '/data');
define('EVENT_UPLOAD_DIR', __DIR__ . '/uploads/events');
define('MAX_EVENT_IMAGE_BYTES', 5 * 1024 * 1024);

if (!is_dir(DATA_DIR)) { @mkdir(DATA_DIR, 0750, true); }
if (!is_dir(EVENT_UPLOAD_DIR)) { @mkdir(EVENT_UPLOAD_DIR, 0750, true); }

function load_json($file, $default = []) {
    if (!is_file($file)) return $default;
    $raw = @file_get_contents($file);
    if ($raw === false || $raw === '') return $default;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $default;
}

function save_json($file, $data) {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) return false;
    $tmp = $file . '.tmp';
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    return @rename($tmp, $file);
}

function json_response($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function start_secure_session() {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

function require_admin() {
    start_secure_session();
    if (empty($_SESSION['admin_authenticated'])) json_response(['ok'=>false,'error'=>'Unauthorized'], 401);
}

function csrf_token() {
    start_secure_session();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function require_csrf() {
    start_secure_session();
    $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf'] ?? '');
    if (!hash_equals($_SESSION['csrf'] ?? '', $sent)) json_response(['ok'=>false,'error'=>'Invalid security token'], 403);
}
