<?php
require_once __DIR__ . '/config.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$action = $_GET['action'] ?? $_POST['action'] ?? '';

function request_json() {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '{}', true);
    return is_array($data) ? $data : [];
}

function clean_text($v, $max=500) {
    $v = trim((string)$v);
    if (strlen($v) > $max) $v = substr($v, 0, $max);
    return $v;
}

function valid_date($v) {
    $d = DateTime::createFromFormat('Y-m-d', $v);
    return $d && $d->format('Y-m-d') === $v;
}

function next_id($items) {
    $max=0; foreach($items as $x) $max=max($max,(int)($x['id']??0)); return $max+1;
}

if ($action === 'login') {
    start_secure_session();
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['ok'=>false,'error'=>'Method not allowed'],405);
    // Basic session-based login throttling.
    $now=time();
    if (!isset($_SESSION['login_attempts'])) $_SESSION['login_attempts']=[];
    $_SESSION['login_attempts']=array_values(array_filter($_SESSION['login_attempts'], fn($t)=>$t>$now-900));
    if (count($_SESSION['login_attempts']) >= 5) json_response(['ok'=>false,'error'=>'Too many login attempts. Try again later.'],429);
    $data=request_json();
    $user=clean_text($data['username']??'',100); $pass=(string)($data['password']??'');
    if (!hash_equals(ADMIN_USERNAME,$user) || !password_verify($pass,ADMIN_PASSWORD_HASH)) {
        $_SESSION['login_attempts'][]=$now;
        usleep(250000);
        json_response(['ok'=>false,'error'=>'Invalid username or password'],401);
    }
    session_regenerate_id(true);
    $_SESSION['admin_authenticated']=true;
    $_SESSION['csrf']=bin2hex(random_bytes(32));
    $_SESSION['login_attempts']=[];
    json_response(['ok'=>true,'csrf'=>$_SESSION['csrf']]);
}

if ($action === 'logout') {
    require_admin(); require_csrf();
    $_SESSION=[];
    if (ini_get('session.use_cookies')) { $p=session_get_cookie_params(); setcookie(session_name(),'',time()-42000,$p['path'],$p['domain']??'',(bool)$p['secure'],(bool)$p['httponly']); }
    session_destroy();
    json_response(['ok'=>true]);
}

if ($action === 'state') {
    start_secure_session();
    json_response(['ok'=>true,'authenticated'=>!empty($_SESSION['admin_authenticated']),'csrf'=>!empty($_SESSION['admin_authenticated'])?csrf_token():null]);
}

require_admin();

if ($action === 'list') {
    json_response(['ok'=>true,'notices'=>load_json(DATA_DIR.'/notices.json',[]),'events'=>load_json(DATA_DIR.'/events.json',[]),'csrf'=>csrf_token()]);
}

require_csrf();

if ($action === 'notice_save') {
    $data=request_json();
    $id=(int)($data['id']??0);
    $date=clean_text($data['date']??'',10); $title=clean_text($data['title']??'',200); $desc=clean_text($data['description']??'',500);
    if (!valid_date($date) || $title==='') json_response(['ok'=>false,'error'=>'Valid date and notice title are required'],422);
    $items=load_json(DATA_DIR.'/notices.json',[]);
    $record=['id'=>$id?:next_id($items),'date'=>$date,'title'=>$title,'description'=>$desc];
    $found=false;
    foreach($items as &$item){ if((int)($item['id']??0)===$id && $id>0){$item=$record;$found=true;break;} } unset($item);
    if(!$found) $items[]=$record;
    usort($items,fn($a,$b)=>strcmp($b['date']??'', $a['date']??''));
    if(!save_json(DATA_DIR.'/notices.json',$items)) json_response(['ok'=>false,'error'=>'Could not save notice'],500);
    json_response(['ok'=>true]);
}

if ($action === 'notice_delete') {
    $data=request_json(); $id=(int)($data['id']??0);
    $items=array_values(array_filter(load_json(DATA_DIR.'/notices.json',[]),fn($x)=>(int)($x['id']??0)!==$id));
    if(!save_json(DATA_DIR.'/notices.json',$items)) json_response(['ok'=>false,'error'=>'Could not delete notice'],500);
    json_response(['ok'=>true]);
}

if ($action === 'event_save') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['ok'=>false,'error'=>'Method not allowed'],405);
    $id=(int)($_POST['id']??0);
    $name=clean_text($_POST['name']??'',200); $date=clean_text($_POST['date']??'',10); $desc=clean_text($_POST['description']??'',500);
    if($name==='' || !valid_date($date)) json_response(['ok'=>false,'error'=>'Event name and valid date are required'],422);
    $items=load_json(DATA_DIR.'/events.json',[]);
    $oldImage=''; $found=false;
    foreach($items as $item){if((int)($item['id']??0)===$id){$oldImage=$item['image']??'';$found=true;break;}}
    $image=$oldImage;
    if(isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE){
        $f=$_FILES['image'];
        if($f['error']!==UPLOAD_ERR_OK || $f['size']>MAX_EVENT_IMAGE_BYTES) json_response(['ok'=>false,'error'=>'Invalid or oversized image'],422);
        $info=@getimagesize($f['tmp_name']);
        if(!$info) json_response(['ok'=>false,'error'=>'Uploaded file is not a valid image'],422);
        $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
        $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
        if(!isset($allowed[$mime])) json_response(['ok'=>false,'error'=>'Only JPG, PNG or WebP images are allowed'],422);
        $filename=bin2hex(random_bytes(16)).'.'.$allowed[$mime];
        $target=EVENT_UPLOAD_DIR.'/'.$filename;
        if(!move_uploaded_file($f['tmp_name'],$target)) json_response(['ok'=>false,'error'=>'Could not save image'],500);
        @chmod($target,0640);
        $image='uploads/events/'.$filename;
        if($oldImage && str_starts_with($oldImage,'uploads/events/')) @unlink(__DIR__.'/'.$oldImage);
    }
    if(!$image) json_response(['ok'=>false,'error'=>'Please select an event image'],422);
    $record=['id'=>$id?:next_id($items),'name'=>$name,'date'=>$date,'description'=>$desc,'image'=>$image];
    $replaced=false; foreach($items as &$item){if((int)($item['id']??0)===$id && $id>0){$item=$record;$replaced=true;break;}} unset($item);
    if(!$replaced)$items[]=$record;
    usort($items,fn($a,$b)=>strcmp($a['date']??'', $b['date']??''));
    if(!save_json(DATA_DIR.'/events.json',$items)) json_response(['ok'=>false,'error'=>'Could not save event'],500);
    json_response(['ok'=>true]);
}

if ($action === 'event_delete') {
    $data=request_json(); $id=(int)($data['id']??0); $items=load_json(DATA_DIR.'/events.json',[]); $kept=[];
    foreach($items as $item){
        if((int)($item['id']??0)===$id){$img=$item['image']??''; if($img && str_starts_with($img,'uploads/events/')) @unlink(__DIR__.'/'.$img);}
        else $kept[]=$item;
    }
    if(!save_json(DATA_DIR.'/events.json',$kept)) json_response(['ok'=>false,'error'=>'Could not delete event'],500);
    json_response(['ok'=>true]);
}

json_response(['ok'=>false,'error'=>'Unknown action'],400);
