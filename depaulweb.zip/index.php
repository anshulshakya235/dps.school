<?php
require_once __DIR__ . '/config.php';
$notices = load_json(DATA_DIR . '/notices.json', []);
$events = load_json(DATA_DIR . '/events.json', []);
function e($value){ return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function notice_day($date){ $t=strtotime($date); return $t ? date('d',$t) : ''; }
function notice_month($date){ $t=strtotime($date); return $t ? strtoupper(date('M',$t)) : ''; }
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>De Paul Junior High School | Badaun</title>

<link rel="stylesheet" href="style.css">

</head>


<body>


<!-- =====================================================
     TOP BAR
===================================================== -->

<aside class="topbar">

<div class="container topbar-inner">

<div>
📍 De Paul Junior High School, Badaun (U.P.)
</div>

<div class="topbar-right">

<a href="tel:+919027269094">
☎ +91 9027269094
</a>

<a href="mailto:depaulschool@gmail.com">
✉ depaulschool@gmail.com
</a>

<a href="#">
Facebook
</a>

<a href="#">
Instagram
</a>

</div>

</div>

</aside>


<!-- =====================================================
     HEADER
===================================================== -->

<header>

<nav class="navbar">

<div class="container navbar-inner">

<a class="navbar-brand" href="#home">

<img
class="logo"
src="image/logo.jpg"
alt="School Logo">

<div class="school-name">

<h1>De Paul Junior High School</h1>

<small>
Badaun (U.P.) • Discipline | Knowledge | Service
</small>

</div>

</a>


<button
class="menu-btn"
id="menuBtn"
type="button"
aria-label="Open menu">

☰

</button>


<ul class="nav-menu" id="navMenu">

<li>
<a href="#home">Home</a>
</li>

<li>
<a href="#about">About</a>
</li>

<li>
<a href="#academics">Academics</a>
</li>

<li>
<a href="#facilities">Facilities</a>
</li>

<li>
<a href="#teachers">Teachers</a>
</li>

<li>
<a href="#gallery">Gallery</a>
</li>

<li>
<a href="#events">Events</a>
</li>

<li>
<a href="#contact">Contact</a>
</li>

</ul>

</div>

</nav>

</header>


<!-- =====================================================
     MAIN
===================================================== -->

<main>


<!-- =====================================================
     HERO
===================================================== -->

<section id="home" class="hero">

<div class="hero-slider" id="heroSlider">


<article
class="hero-slide active"
style="background-image:url('image/school1.jpg')">

<div class="hero-content">

<span>
WELCOME TO DE PAUL JUNIOR HIGH SCHOOL
</span>

<h2>
Building a <b>Brighter</b><br>
Future Together
</h2>

<p>
We nurture young minds with knowledge, values,
discipline and confidence to help them reach
greater heights.
</p>

<a href="#about" class="btn-main">
Explore More →
</a>

<a href="#contact" class="btn-outline">
Contact Us
</a>

</div>

</article>


<article
class="hero-slide"
style="background-image:url('image/school2.jpg')">

<div class="hero-content">

<span>
EDUCATION • VALUES • EXCELLENCE
</span>

<h2>
Learn Today.<br>
<b>Lead Tomorrow.</b>
</h2>

<p>
Quality education with modern learning,
experienced teachers and value-based development.
</p>

<a href="#academics" class="btn-main">
Our Academics
</a>

</div>

</article>


<article
class="hero-slide"
style="background-image:url('image/school3.jpg')">

<div class="hero-content">

<span>
DISCOVER • LEARN • GROW
</span>

<h2>
Education Beyond<br>
<b>Classrooms</b>
</h2>

<p>
Sports, cultural activities, technology,
creativity and teamwork for complete development.
</p>

<a href="#facilities" class="btn-main">
Discover Facilities
</a>

</div>

</article>


<div class="slider-controls">

<button id="prevSlide">
‹
</button>

<button id="nextSlide">
›
</button>

</div>


<div class="slider-dots">

<button class="slider-dot active"></button>
<button class="slider-dot"></button>
<button class="slider-dot"></button>

</div>

</div>

</section>


<!-- =====================================================
     ABOUT
===================================================== -->

<section id="about">

<div class="container">

<div class="row align-center">


<div class="col-6 reveal left">

<figure>

<img
class="about-img"
src="image/campus.jpg"
alt="School Building">

<figcaption style="text-align:center;margin-top:8px;color:#777;">
Our School Campus
</figcaption>

</figure>

</div>


<div class="col-6 about-content reveal right">

<span style="color:#f5b400;font-weight:700;">
ABOUT OUR SCHOOL
</span>

<h2>
Education With Purpose
</h2>

<p>
De Paul Junior High School, Badaun is committed
to providing quality education in a safe,
supportive and inspiring environment.
</p>

<p>
Our objective is to develop students academically,
socially, creatively and morally so that they become
responsible citizens of society.
</p>


<div class="row">

<div class="col-6">

<div class="info-box">

<div class="info-icon">📅</div>

<div>

<strong>Established</strong>

<br>

<small>1990</small>

</div>

</div>

</div>


<div class="col-6">

<div class="info-box">

<div class="info-icon">🏫</div>

<div>

<strong>Education</strong>

<br>

<small>Value Based</small>

</div>

</div>

</div>

</div>

<br>

<a href="#contact" class="btn-main">
Know More
</a>

</div>

</div>

</div>

</section>


<!-- =====================================================
     FEATURES
===================================================== -->

<section class="features">

<div class="container">

<div class="section-title">

<span>WHY CHOOSE US</span>

<h2>Our Key Features</h2>

<p>
We focus on creating a complete learning
experience for every student.
</p>

</div>


<div class="row">


<div class="col-4 reveal">

<article class="feature-card">

<div class="feature-icon">🎓</div>

<h4>Quality Education</h4>

<p>
Strong academic foundation with
student-focused teaching.
</p>

</article>

</div>


<div class="col-4 reveal">

<article class="feature-card">

<div class="feature-icon">👨‍🏫</div>

<h4>Experienced Teachers</h4>

<p>
Dedicated teachers helping students
discover their potential.
</p>

</article>

</div>


<div class="col-4 reveal">

<article class="feature-card">

<div class="feature-icon">🛡️</div>

<h4>Safe Campus</h4>

<p>
A secure and friendly environment
for learning and growth.
</p>

</article>

</div>


<div class="col-4 reveal">

<article class="feature-card">

<div class="feature-icon">🔬</div>

<h4>Modern Labs</h4>

<p>
Science and computer facilities
for practical learning.
</p>

</article>

</div>


<div class="col-4 reveal">

<article class="feature-card">

<div class="feature-icon">⚽</div>

<h4>Sports</h4>

<p>
Physical activities for healthy
mind and body.
</p>

</article>

</div>


<div class="col-4 reveal">

<article class="feature-card">

<div class="feature-icon">🎨</div>

<h4>Creative Activities</h4>

<p>
Arts, culture, competitions and
creative learning opportunities.
</p>

</article>

</div>

</div>

</div>

</section>


<!-- =====================================================
     COUNTERS
===================================================== -->

<section class="counter-section">

<div class="container">

<div class="row">


<div class="col-3">

<div class="counter-box">

<div class="counter-icon">🎓</div>

<div
class="counter"
data-target="500">
0
</div>

<p>Current Students </p>

</div>

</div>


<div class="col-3">

<div class="counter-box">

<div class="counter-icon">👨‍🏫</div>

<div
class="counter"
data-target="20">
0
</div>

<p>Qualified Teachers</p>

</div>

</div>


<div class="col-3">

<div class="counter-box">

<div class="counter-icon">🏆</div>

<div
class="counter"
data-target="35">
0
</div>

<p>Years of Excellence</p>

</div>

</div>


<div class="col-3">

<div class="counter-box">

<div class="counter-icon">%</div>

<div
class="counter"
data-target="12000">
0
</div>

<p>Graduated Student</p>

</div>

</div>

</div>

</div>

</section>


<!-- =====================================================
     ACADEMICS
===================================================== -->

<section id="academics">

<div class="container">

<div class="section-title">

<span>ACADEMICS</span>

<h2>Our Academic Programs</h2>

</div>


<div class="row">


<div class="col-4 reveal">

<article class="academic-card">

<div class="academic-icon">
📖
</div>

<h4>Primary Classes</h4>

<p>Classes 1 – 5</p>

<progress value="90" max="100"></progress>

<p>
Strong foundation through interactive
and activity-based learning.
</p>

</article>

</div>


<div class="col-4 reveal">

<article class="academic-card">

<div class="academic-icon">
⚛️
</div>

<h4>Middle Classes</h4>

<p>Classes 6 – 8</p>

<meter value="0.85">
85%
</meter>

<p>
Concept-based learning with practical
activities and projects.
</p>

</article>

</div>


<div class="col-4 reveal">

<article class="academic-card">

<div class="academic-icon">
💻
</div>

<h4>Computer Education</h4>

<p>Digital Learning</p>

<details>

<summary>
View Details
</summary>

<p>
Computer fundamentals, internet,
digital literacy and technology-based
learning.
</p>

</details>

</article>

</div>

</div>

</div>

</section>


<!-- =====================================================
     NOTICE
===================================================== -->

<section class="notice-area">

<div class="container">

<div class="section-title">

<span>STAY UPDATED</span>

<h2>Notice Board</h2>

</div>


<div class="row">


<div class="col-8 reveal">

<div class="notice-board">

<div class="notice-head">

<h4>
📢 Latest Notices
</h4>

</div>

<?php if (!$notices): ?>
<article class="notice">
<div>
<strong>No latest notices available.</strong>
</div>
</article>
<?php else: ?>
<?php foreach ($notices as $notice): ?>
<article class="notice">

<time class="notice-date">
<?= e(notice_day($notice['date'] ?? '')) ?><br><?= e(notice_month($notice['date'] ?? '')) ?>
</time>

<div>

<strong><?= e($notice['title'] ?? '') ?></strong>

<?php if (!empty($notice['description'])): ?>
<p><?= e($notice['description']) ?></p>
<?php endif; ?>

</div>

</article>
<?php endforeach; ?>
<?php endif; ?>

</div>

</div>


<div class="col-4 reveal">

<aside class="principal">

<h4 style="color:#073b78;">
Principal's Message
</h4>

<img
src="image/principal.jpg"
alt="Principal">

<blockquote style="margin-top:15px;">
"Education is not just about academic excellence;
it is about building character, confidence and
responsibility."
</blockquote>

<strong>
—Mr.Dharmesh Sharma[Principal]
</strong>

</aside>

</div>

</div>

</div>

</section>


<!-- =====================================================
     FACILITIES
===================================================== -->

<section id="facilities">

<div class="container">

<div class="section-title">

<span>OUR CAMPUS</span>

<h2>World of Learning</h2>

</div>


<div class="row">


<div class="col-3 reveal">

<article class="facility-card">

<div class="feature-icon">
🔬
</div>

<h5>Science Lab</h5>

</article>

</div>


<div class="col-3 reveal">

<article class="facility-card">

<div class="feature-icon">
💻
</div>

<h5>Computer Lab</h5>

</article>

</div>


<div class="col-3 reveal">

<article class="facility-card">

<div class="feature-icon">
📚
</div>

<h5>Library</h5>

</article>

</div>


<div class="col-3 reveal">

<article class="facility-card">

<div class="feature-icon">
⚽
</div>

<h5>Playground</h5>

</article>

</div>

</div>

</div>

</section>


<!-- =====================================================
     TEACHERS
===================================================== -->

<section id="teachers" class="features">

<div class="container">

<div class="section-title">

<span>OUR FACULTY</span>

<h2>Meet Our Teachers</h2>

</div>


<div class="row">


<div class="col-3 reveal">

<article class="teacher-card">

<img
src="image/principal.jpg"
alt="Teacher">

<div class="teacher-info">

<h5>Mr.Dharmesh sharma</h5>

<p>Principal</p>

</div>

</article>

</div>


<div class="col-3 reveal">

<article class="teacher-card">

<img
src="image/dhara.jpg"
alt="Teacher">

<div class="teacher-info">

<h5>Mr.Prempal shakya</h5>

<p>Teacher</p>

</div>

</article>

</div>


<div class="col-3 reveal">

<article class="teacher-card">

<img
src="image/preal.jpg"
alt="Teacher">

<div class="teacher-info">

<h5>Mr. Dharmendra pal shakya</h5>

<p>Former Teacher (Social science)</p>

</div>

</article>

</div>


<div class="col-3 reveal">

<article class="teacher-card">

<img
src="image/ompal.jpg"
alt="Teacher">

<div class="teacher-info">

<h5>Ompal singh shakya</h5>

<p>Former Teacher (mathmatics)</p>

</div>

</article>

</div>

</div>

</div>

</section>


<!-- =====================================================
     GALLERY
===================================================== -->

<section id="gallery" class="gallery">

<div class="container">

<div class="section-title">

<span>PHOTO GALLERY</span>

<h2>Our Memories</h2>

</div>


<div class="row">


<div class="col-4 reveal">

<figure class="gallery-item">

<img
src="image/Memory1.jpg"
alt="Students">

<figcaption class="gallery-overlay">

<span>⌕</span>

</figcaption>

</figure>

</div>


<div class="col-4 reveal">

<figure class="gallery-item">

<img
src="image/Memory2.jpg"
alt="Classroom">

<figcaption class="gallery-overlay">

<span>⌕</span>

</figcaption>

</figure>

</div>


<div class="col-4 reveal">

<figure class="gallery-item">

<img
src="image/Memory3.jpg"
alt="Activity">

<figcaption class="gallery-overlay">

<span>⌕</span>

</figcaption>

</figure>

</div>


<div class="col-6 reveal">

<figure class="gallery-item">

<img
src="image/learning.jpg"
alt="Students Learning">

<figcaption class="gallery-overlay">

<span>▣</span>

</figcaption>

</figure>

</div>


<div class="col-6 reveal">

<figure class="gallery-item">

<img
src="image/school.jpg"
alt="School">

<figcaption class="gallery-overlay">

<span>▣</span>

</figcaption>

</figure>

</div>

</div>

</div>

</section>


<!-- =====================================================
     EVENTS
===================================================== -->

<section id="events">

<div class="container">

<div class="section-title">

<span>WHAT'S HAPPENING</span>

<h2>Upcoming Events</h2>

</div>


<div class="row">

<?php if (!$events): ?>
<div class="col-12 reveal">
<p style="text-align:center;">No upcoming events available.</p>
</div>
<?php else: ?>
<?php foreach ($events as $event): ?>
<div class="col-4 reveal">

<article class="event-card">

<?php if (!empty($event['image'])): ?>
<img src="<?= e($event['image']) ?>" alt="<?= e($event['name'] ?? 'School Event') ?>">
<?php endif; ?>

<div class="event-content">

<time class="event-date">
<?= e(date('d F Y', strtotime($event['date'] ?? ''))) ?>
</time>

<h4><?= e($event['name'] ?? '') ?></h4>

<?php if (!empty($event['description'])): ?>
<p><?= e($event['description']) ?></p>
<?php endif; ?>

</div>

</article>

</div>
<?php endforeach; ?>
<?php endif; ?>

</div>

</div>

</section>


<!-- =====================================================
     ADMISSION
===================================================== -->

<section class="admission">

<div class="container" style="text-align:center;">

<span style="color:#f5b400;font-weight:700;">
ADMISSIONS OPEN
</span>

<h2 style="margin-top:15px;">
Give Your Child a Brighter Future
</h2>

<p>
Admissions for academic session 2026–27
are now open.
</p>

<a href="#contact" class="btn-main">
Apply Now →
</a>

</div>

</section>


<!-- =====================================================
     FAQ
===================================================== -->

<section class="faq">

<div class="container">

<div class="section-title">

<span>FAQ</span>

<h2>
Frequently Asked Questions
</h2>

</div>


<details>

<summary>
What is the admission process?
</summary>

<p>
Contact the school office and submit the
required admission form and documents.
</p>

</details>


<details>

<summary>
What are the school timings?
</summary>

<p>
School timings may vary according to class
and academic schedule.
</p>

</details>


<details>

<summary>
Does the school have sports activities?
</summary>

<p>
Yes. Students can participate in various
sports and physical activities.
</p>

</details>


<details>

<summary>
How can I contact the school?
</summary>

<p>
You can contact the school through phone,
email or by visiting the campus.
</p>

</details>

</div>

</section>


<!-- =====================================================
     CONTACT
===================================================== -->

<section id="contact" class="features">

<div class="container">

<div class="section-title">

<span>GET IN TOUCH</span>

<h2>
Contact Our School
</h2>

</div>


<div class="row">


<div class="col-5 reveal">

<address class="contact-card">

<div class="contact-item">

<div class="contact-icon">
📍
</div>

<div>

<strong>Address</strong>

<p>
De Paul Junior High School,<br>
Badaun, Uttar Pradesh, India
</p>

</div>

</div>


<div class="contact-item">

<div class="contact-icon">
☎
</div>

<div>

<strong>Phone</strong>

<p>
+91 9027269094
</p>

</div>

</div>


<div class="contact-item">

<div class="contact-icon">
✉
</div>

<div>

<strong>Email</strong>

<p>
depaulschool@gmail.com
</p>

</div>

</div>

</address>

</div>


<div class="col-7 reveal">

<form
class="contact-card"
id="contactForm">

<h3 style="color:#073b78;margin-bottom:20px;">
Send Us a Message
</h3>


<div class="form-row">

<div class="form-group">

<label for="name">
Your Name
</label>

<input
id="name"
class="form-control"
type="text"
placeholder="Enter your name"
required>

</div>


<div class="form-group">

<label for="email">
Email
</label>

<input
id="email"
class="form-control"
type="email"
placeholder="Enter your email"
required>

</div>

</div>


<div class="form-group">

<label for="subject">
Subject
</label>

<input
id="subject"
class="form-control"
type="text"
placeholder="Message subject"
required>

</div>


<div class="form-group">

<label for="message">
Message
</label>

<textarea
id="message"
class="form-control"
rows="5"
placeholder="Write your message..."
required></textarea>

</div>


<button
class="btn-main"
type="submit">

Send Message →

</button>

</form>

</div>

</div>

</div>

</section>

</main>


<!-- =====================================================
     FOOTER
===================================================== -->

<footer>

<div class="container">

<div class="row">


<div class="col-4">

<h4>
De Paul Junior High School
</h4>

<p>
Discipline • Knowledge • Service
</p>

<p>
Building responsible, confident and
knowledgeable young minds.
</p>

<div class="social">

<a href="#">F</a>

<a href="#">I</a>

<a href="#">Y</a>

<a href="#">W</a>

</div>

</div>


<div class="col-2">

<h4>
Quick Links
</h4>

<ul>

<li>
<a href="#home">Home</a>
</li>

<li>
<a href="#about">About</a>
</li>

<li>
<a href="#academics">Academics</a>
</li>

<li>
<a href="#teachers">Teachers</a>
</li>

</ul>

</div>


<div class="col-3">

<h4>
Useful Links
</h4>

<ul>

<li>
<a href="#facilities">Facilities</a>
</li>

<li>
<a href="#gallery">Gallery</a>
</li>

<li>
<a href="#events">Events</a>
</li>

<li>
<a href="#contact">Contact</a>
</li>

</ul>

</div>


<div class="col-3">

<h4>
School Motto
</h4>

<p>
<em>
"To the Heights"
</em>
</p>

<p>
Created by
<strong>Anshul Shakya</strong>
</p>
<a href="https://depaulschool.site.je/image/admin.html">Admin Login</a>
</div>

</div>


<div class="copyright">

&copy;
<span id="year"></span>

De Paul Junior High School.
All Rights Reserved.

</div>

</div>

</footer>


<!-- =====================================================
     FLOATING BUTTONS
===================================================== -->

<a
class="whatsapp"
href="https://wa.me/9027269094"
target="_blank"
aria-label="WhatsApp">

W

</a>


<button
id="topBtn"
aria-label="Back to top">

↑

</button>


<!-- =====================================================
     JAVASCRIPT
===================================================== -->

<script>


/* =====================================================
   MOBILE MENU
===================================================== */

const menuBtn =
document.getElementById("menuBtn");

const navMenu =
document.getElementById("navMenu");


menuBtn.addEventListener("click",function(){

    navMenu.classList.toggle("active");

    if(navMenu.classList.contains("active")){
        menuBtn.innerHTML="✕";
    }else{
        menuBtn.innerHTML="☰";
    }

});


document
.querySelectorAll("#navMenu a")
.forEach(function(link){

    link.addEventListener("click",function(){

        navMenu.classList.remove("active");

        menuBtn.innerHTML="☰";

    });

});


/* =====================================================
   HERO SLIDER
===================================================== */

const slides =
document.querySelectorAll(".hero-slide");

const dots =
document.querySelectorAll(".slider-dot");

const nextBtn =
document.getElementById("nextSlide");

const prevBtn =
document.getElementById("prevSlide");

let currentSlide=0;

let sliderTimer;


function showSlide(index){

    if(index >= slides.length){
        currentSlide=0;
    }

    else if(index < 0){
        currentSlide=slides.length-1;
    }

    else{
        currentSlide=index;
    }


    slides.forEach(function(slide){

        slide.classList.remove("active");

    });


    dots.forEach(function(dot){

        dot.classList.remove("active");

    });


    slides[currentSlide]
    .classList.add("active");


    dots[currentSlide]
    .classList.add("active");

}


function nextSlide(){

    showSlide(currentSlide+1);

}


function previousSlide(){

    showSlide(currentSlide-1);

}


nextBtn.addEventListener(
    "click",
    function(){

        nextSlide();

        restartSlider();

    }
);


prevBtn.addEventListener(
    "click",
    function(){

        previousSlide();

        restartSlider();

    }
);


dots.forEach(function(dot,index){

    dot.addEventListener(
        "click",
        function(){

            showSlide(index);

            restartSlider();

        }
    );

});


function startSlider(){

    sliderTimer=setInterval(
        nextSlide,
        5000
    );

}


function restartSlider(){

    clearInterval(sliderTimer);

    startSlider();

}


startSlider();


/* =====================================================
   COUNTERS
===================================================== */

const counters =
document.querySelectorAll(".counter");


function animateCounter(counter){

    const target =
    Number(counter.dataset.target);

    let number=0;

    const duration=1800;

    const startTime=
    performance.now();


    function update(time){

        const progress =
        Math.min(
            (time-startTime)/duration,
            1
        );


        const value =
        Math.floor(
            progress*target
        );


        counter.textContent=value;


        if(progress<1){

            requestAnimationFrame(update);

        }

        else{

            counter.textContent=
            target+"+";

        }

    }


    requestAnimationFrame(update);

}


const counterObserver =
new IntersectionObserver(
function(entries){

    entries.forEach(function(entry){

        if(entry.isIntersecting){

            animateCounter(
                entry.target
            );

            counterObserver.unobserve(
                entry.target
            );

        }

    });

},
{
    threshold:.5
});


counters.forEach(function(counter){

    counterObserver.observe(counter);

});


/* =====================================================
   SCROLL REVEAL
===================================================== */

const revealElements =
document.querySelectorAll(".reveal");


const revealObserver =
new IntersectionObserver(
function(entries){

    entries.forEach(function(entry){

        if(entry.isIntersecting){

            entry.target
            .classList
            .add("show");

            revealObserver.unobserve(
                entry.target
            );

        }

    });

},
{
    threshold:.12
});


revealElements.forEach(function(element){

    revealObserver.observe(element);

});


/* =====================================================
   BACK TO TOP
===================================================== */

const topBtn =
document.getElementById("topBtn");


window.addEventListener(
"scroll",
function(){

    if(window.scrollY>500){

        topBtn.style.display="grid";

    }

    else{

        topBtn.style.display="none";

    }

});


topBtn.addEventListener(
"click",
function(){

    window.scrollTo({

        top:0,

        behavior:"smooth"

    });

});


/* =====================================================
   CONTACT FORM
===================================================== */

document
.getElementById("contactForm")
.addEventListener(
"submit",
function(event){

    event.preventDefault();


    const name =
    document.getElementById("name").value;


    alert(
        "Thank you "+name+
        "! Your message has been received."
    );


    this.reset();

});


/* =====================================================
   CURRENT YEAR
===================================================== */

document.getElementById("year")
.textContent =
new Date().getFullYear();


/* =====================================================
   IMAGE LAZY LOAD
===================================================== */

document
.querySelectorAll("img")
.forEach(function(img){

    img.loading="lazy";

});


</script>

</body>
</html>