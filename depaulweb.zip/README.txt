# De Paul Junior High School — PHP Admin Version

## Upload structure
Upload the contents to your InfinityFree `htdocs` folder.

Required school images (you add these yourself):
- image/logo.jpg
- image/school1.jpg
- image/school2.jpg
- image/school3.jpg
- image/campus.jpg
- image/principal.jpg
- image/dhash.jpg
- image/dhara.jpg
- image/preal.jpg
- image/ompal.jpg
- image/Memory1.jpg
- image/Memory2.jpg
- image/Memory3.jpg

Admin URL: `/image/admin.html`
Default username: `admin`
Default password: `Admin@2026#School`

Change the default password hash in `config.php` before public use. Generate a new hash with PHP:
`php -r "echo password_hash('YOUR_NEW_PASSWORD', PASSWORD_DEFAULT), PHP_EOL;"`

Data is stored server-side in JSON files under `data/`. Event uploads are stored under `uploads/events/`.

The admin API requires an authenticated PHP session and CSRF token. Uploads are restricted to JPG/PNG/WebP and 5 MB.
